// Small DOM + formatting helpers shared by every module.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

export const icon = (name, cls = "") => `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

/**
 * Every coin/chain bubble renders its plain-letter fallback as real text
 * content immediately (so it's never blank and needs no network/JS to
 * appear), then layers a real logo <img> on top of it via a static URL
 * (see the `logo` field in data.js). This is a plain <img src>, not a
 * fetch()/XHR call, so it is never subject to CORS and doesn't depend on
 * this deployment's own /api/* routes being reachable. If the image 404s
 * or otherwise fails to load, its inline onerror just removes the <img>
 * element — the letter-bubble underneath was there the whole time, so the
 * bubble can never end up rendering blank.
 */
function tokBubble(logoUrl, fallbackText, hue, size, extraClass = "") {
  const cls = `tok ${size}${extraClass}`.trim();
  const img = logoUrl
    ? `<img class="logo" src="${esc(logoUrl)}" alt="" loading="lazy" aria-hidden="true" onerror="this.remove()">`
    : "";
  return `<span class="${cls}" style="--h:${hue}" aria-hidden="true">${esc(fallbackText)}${img}</span>`;
}

/** A coin's real logo (with a letter-bubble fallback) for use anywhere a token is shown. */
export function tokenAvatar(token, size = "") {
  const long = token.symbol.length > 3 ? " long" : "";
  return tokBubble(token.logo, token.symbol.slice(0, 4), token.hue, size, long);
}

/** A network's real logo (with a letter-bubble fallback) for use anywhere a chain is shown. */
export function chainGlyph(chain, size = "") {
  return tokBubble(chain.logo, chain.name[0], chain.hue, size);
}

let toastTimer;
export function toast(message) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}

/** USD price with sensible precision for both $60,000 assets and $0.00002 assets. */
export function fmtUsd(n) {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1000) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (n >= 1) return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (n <= 0) return "$0.00";
  const decimals = Math.min(12, Math.max(2, 2 - Math.floor(Math.log10(n))));
  return "$" + n.toFixed(decimals);
}

/** Plain machine-friendly number string (no grouping, no exponent, trailing zeros trimmed). */
export function plain(n) {
  if (n == null || !isFinite(n)) return "";
  let s;
  if (n >= 1000) s = n.toFixed(2);
  else if (n >= 1) s = n.toFixed(4);
  else if (n <= 0) s = "0";
  else s = n.toFixed(Math.min(12, Math.max(6, 3 - Math.floor(Math.log10(n)))));
  return s.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, "");
}

/** Grouped amount for display. */
export function fmtAmount(n) {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return Number(plain(n)).toLocaleString("en-US", { maximumFractionDigits: 12 });
}

export function fmtChange(n) {
  if (n == null || !isFinite(n)) return { text: "—", dir: "flat" };
  const dir = n > 0.005 ? "up" : n < -0.005 ? "down" : "flat";
  const glyph = dir === "up" ? "▲" : dir === "down" ? "▼" : "•";
  return { text: `${glyph} ${Math.abs(n).toFixed(2)}%`, dir };
}

export function debounce(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { /* ignore */ }
    ta.remove();
    return ok;
  }
}

export function openDialog(dlg) {
  if (!dlg.open) dlg.showModal();
}

/** Wire backdrop-click and [data-close] buttons on every dialog once. */
export function initDialogs() {
  $$("dialog.sheet").forEach((dlg) => {
    // Delegated so buttons rendered into a dialog later (previews, deploy summary) also close it.
    dlg.addEventListener("click", (e) => {
      if (e.target === dlg || e.target.closest("[data-close]")) dlg.close();
    });
  });
}

export function friendlyError(e) {
  const msg = (e && (e.message || e.reason)) || "";
  if (e && (e.code === 4001 || e.code === "ACTION_REJECTED" || /reject|denied|declin|cancel/i.test(msg))) return "You cancelled the request in your wallet.";
  if (e && e.code === -32002) return "A request is already open in your wallet. Check the extension.";
  return msg || "The wallet request failed. Try again.";
}
