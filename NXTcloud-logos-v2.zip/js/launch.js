// NXT Launchpad: four-step guided token setup with real validation and preflight checks.
import { CHAINS, FAMILY_LABEL, TOKENS, TREASURY, chainById } from "./data.js";
import { store } from "./store.js";
import * as wallet from "./wallet.js";
import { openWalletDialog } from "./wallet-ui.js";
import { getPrices } from "./api.js";
import { $, $$, esc, icon, toast, copyText, chainGlyph, openDialog, friendlyError, plain } from "./ui.js";

const LAUNCH_FEE_USD = 1;
const BRANDING_FEE_USD = 5;
const BRAND_TAG = "Deployed by NXT CLOUD";
const freshFee = () => ({ quoteChain: null, quote: null, quoteLoading: false, quoteError: null, paying: false, tx: null, error: null });

const STEPS = ["Network", "Token", "Review", "Deploy"];
const U64_MAX = 2n ** 64n - 1n;

const S = {
  step: 1,
  reached: 1,
  name: "",
  symbol: "",
  supply: "",
  decimals: "",
  decimalsTouched: false,
  desc: "",
  website: "",
  twitter: "",
  telegram: "",
  discord: "",
  confirmed: false,
  errors: {},
  active: false,
  brandingRemoved: false,
  // Both are paid in the deploy chain's native token, to the same treasury wallet.
  fees: { launch: freshFee(), brand: freshFee() },
};

const SOCIAL_FIELDS = ["website", "twitter", "telegram", "discord"];

const chain = () => chainById(store.get().chain);
const decimals = () => (S.decimalsTouched && S.decimals !== "" ? Number(S.decimals) : chain().defaultDecimals);
const familyName = (c) => FAMILY_LABEL[c.family];

/* ---------------- draft persistence ---------------- */

function loadDraft() {
  try {
    const d = JSON.parse(localStorage.getItem("nxt.draft") || "null");
    if (!d) return;
    S.name = String(d.name || "").slice(0, 32);
    S.symbol = String(d.symbol || "").toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
    S.supply = String(d.supply || "").replace(/\D/g, "").slice(0, 24);
    S.desc = String(d.desc || "").slice(0, 200);
    for (const key of SOCIAL_FIELDS) S[key] = String(d[key] || "").slice(0, 100);
    if (d.decimalsTouched && /^\d{1,2}$/.test(String(d.decimals))) { S.decimals = String(d.decimals); S.decimalsTouched = true; }
  } catch { /* ignore */ }
}
function saveDraft() {
  try {
    localStorage.setItem("nxt.draft", JSON.stringify({
      name: S.name, symbol: S.symbol, supply: S.supply, desc: S.desc,
      decimals: S.decimals, decimalsTouched: S.decimalsTouched,
      website: S.website, twitter: S.twitter, telegram: S.telegram, discord: S.discord,
    }));
  } catch { /* ignore */ }
}

/* ---------------- validation ---------------- */

const SOCIAL_LABEL = { website: "Website", twitter: "X (Twitter)", telegram: "Telegram", discord: "Discord" };
// Accepts a bare domain/URL ("t.me/token") or an @handle for the handle-based ones.
const isValidSocial = (key, v) => (key === "website" ? /^(https?:\/\/)?[^\s.]+(\.[^\s.]+)+(\/\S*)?$/i.test(v) : /^(https?:\/\/\S+|@?[\w.]{2,32})$/i.test(v));

function validate() {
  const e = {};
  const name = S.name.trim();
  if (name.length < 2) e.name = "Enter a name with at least 2 characters.";
  if (S.symbol.length < 2) e.symbol = "Use 2 to 10 letters or numbers.";

  for (const key of SOCIAL_FIELDS) {
    const v = S[key].trim();
    if (v && !isValidSocial(key, v)) e[key] = key === "website" ? "Enter a valid website link." : `Enter a valid ${SOCIAL_LABEL[key]} link or @handle.`;
  }

  let supplyOk = false;
  if (!/^\d+$/.test(S.supply) || BigInt(S.supply) <= 0n) e.supply = "Enter a whole number greater than zero.";
  else supplyOk = true;

  const d = decimals();
  if (!Number.isInteger(d) || d < 0 || d > 18) e.decimals = "Use a whole number from 0 to 18.";
  else if (supplyOk && chain().family !== "evm") {
    const raw = BigInt(S.supply) * 10n ** BigInt(d);
    if (raw > U64_MAX) e.supply = `On ${chain().name}, supply × 10^${d} must fit in 64 bits (about 1.8 × 10^19). Lower the supply or the decimals.`;
  }
  return e;
}

const groupSupply = (s) => (/^\d+$/.test(s) ? s.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : "—");

function socials() {
  const out = {};
  for (const key of SOCIAL_FIELDS) { const v = S[key].trim(); if (v) out[key] = v; }
  return out;
}

/** Every token's description carries the NXT CLOUD credit unless the $5 removal fee was paid. */
function finalDescription() {
  const base = S.desc.trim();
  if (S.brandingRemoved) return base;
  return base ? `${base} — ${BRAND_TAG}` : BRAND_TAG;
}

function feeSummary(fee, usd) {
  return {
    usd,
    native: fee.quote ? { amount: fee.quote.amount, symbol: fee.quote.symbol } : null,
    tx: fee.tx || null,
  };
}

function config() {
  const c = chain();
  return {
    schema: "nxt-cloud/token-config@1",
    network: c.name,
    family: c.family,
    token: { name: S.name.trim(), symbol: S.symbol, totalSupply: S.supply, decimals: decimals(), description: finalDescription(), socials: socials() },
    deployer: wallet.get().address || null,
    fees: {
      treasury: treasuryAddress(c),
      launch: feeSummary(S.fees.launch, LAUNCH_FEE_USD),
      branding: { ...feeSummary(S.fees.brand, BRANDING_FEE_USD), removed: S.brandingRemoved },
    },
    createdAt: new Date().toISOString(),
  };
}

/* ---------------- fees (launch + branding removal, same treasury) ---------------- */

const treasuryAddress = (c) => (c.family === "solana" ? TREASURY.solana : TREASURY.evm);

/** Kicks off (or reuses) a live-price fetch for a $-denominated fee, converted to the current chain's native token. */
function ensureFeeQuote(fee, usdAmount) {
  const c = chain();
  if (fee.quoteChain === c.id && (fee.quote || fee.quoteLoading || fee.quoteError)) return;
  fee.quoteChain = c.id;
  fee.quote = null;
  fee.quoteError = null;
  const nativeToken = TOKENS[c.native];
  if (!nativeToken || !nativeToken.cg) {
    fee.quoteError = `No live price feed for ${c.native}.`;
    return;
  }
  fee.quoteLoading = true;
  getPrices([nativeToken.cg]).then((data) => {
    if (fee.quoteChain !== c.id) return; // stale: chain changed while this was in flight
    fee.quoteLoading = false;
    const usd = data[nativeToken.cg] && data[nativeToken.cg].usd;
    if (!usd) { fee.quoteError = "Couldn't fetch a live price for this fee."; return; }
    fee.quote = { usd, amount: usdAmount / usd, symbol: c.native };
  }).catch(() => {
    if (fee.quoteChain !== c.id) return;
    fee.quoteLoading = false;
    fee.quoteError = "Couldn't fetch a live price for this fee.";
  }).finally(() => {
    if (S.active) renderBody(false);
  });
}

/** Sends `fee`'s quoted amount to the treasury wallet. Calls onPaid() once the tx hash comes back. */
async function payFee(fee, usdAmount, onPaid) {
  if (fee.paying || !fee.quote || fee.tx) return;
  const c = chain();
  fee.paying = true;
  fee.error = null;
  renderBody(false);
  try {
    const to = treasuryAddress(c);
    const hash = c.family === "solana"
      ? await wallet.sendSolanaNative(to, fee.quote.amount)
      : await wallet.sendEvmNative(c, to, fee.quote.amount);
    fee.tx = hash;
    if (onPaid) onPaid();
    toast(`$${usdAmount} fee sent — thanks!`);
  } catch (e) {
    fee.error = friendlyError(e);
    toast(fee.error);
  } finally {
    fee.paying = false;
    renderBody(false);
  }
}

/* ---------------- preflight ---------------- */

function preflight() {
  const c = chain();
  const w = wallet.get();
  const checks = [];
  const complete = Object.keys(validate()).length === 0;
  checks.push({
    ok: complete,
    text: complete ? "Token details are complete" : "Some token details are missing or invalid",
    fix: complete ? null : { label: "Edit details", run: () => goto(2) },
  });

  if (c.family === "sui") {
    checks.push({ ok: false, text: "Sui wallets aren't supported yet", fix: null });
    return checks;
  }
  if (!w.address) {
    checks.push({ ok: false, text: `Connect a ${familyName(c)} wallet`, fix: { label: "Connect wallet", run: openWalletDialog } });
    return checks;
  }
  if (!wallet.matchesFamily(c)) {
    checks.push({ ok: false, text: `Your wallet is on ${wallet.networkLabel()}, but ${c.name} needs a ${familyName(c)} wallet`, fix: { label: "Change wallet", run: openWalletDialog } });
    return checks;
  }
  checks.push({ ok: true, text: `${familyName(c)} wallet connected (${wallet.shortAddress()})` });
  if (c.family === "evm") {
    const onChain = w.chainId === c.chainId;
    checks.push({
      ok: onChain,
      text: onChain ? `Wallet is on ${c.name}` : `Wallet is on ${wallet.networkLabel()}. Switch to ${c.name}`,
      fix: onChain ? null : {
        label: `Switch to ${c.name}`,
        run: async () => { try { await wallet.switchEvmChain(c); } catch (e) { toast(friendlyError(e)); } },
      },
    });
    if (!onChain) return checks; // fee can't be sent until the wallet is on the right network
  }

  const fee = S.fees.launch;
  ensureFeeQuote(fee, LAUNCH_FEE_USD);
  const to = treasuryAddress(c);
  let feeText;
  if (fee.tx) feeText = `$${LAUNCH_FEE_USD} launch fee paid to the treasury wallet (${wallet.shortAddress(to)})`;
  else if (fee.quoteLoading) feeText = `Fetching a live price for the $${LAUNCH_FEE_USD} launch fee…`;
  else if (fee.quoteError) feeText = fee.quoteError;
  else if (fee.quote) feeText = `Pay the $${LAUNCH_FEE_USD} launch fee (~${plain(fee.quote.amount)} ${fee.quote.symbol}) to the treasury wallet (${wallet.shortAddress(to)})`;
  else feeText = `Preparing the $${LAUNCH_FEE_USD} launch fee…`;
  checks.push({
    ok: !!fee.tx,
    text: feeText,
    fix: fee.tx || fee.paying || !fee.quote ? null : { label: "Pay fee", run: () => payFee(fee, LAUNCH_FEE_USD) },
  });
  return checks;
}

/* ---------------- rendering ---------------- */

function renderStepper() {
  $("#stepper").innerHTML = STEPS.map((label, i) => {
    const n = i + 1;
    const state = n < S.step ? "done" : n === S.step ? "current" : "todo";
    const reachable = n <= S.reached && n !== S.step;
    return `<li class="${state}">
      <button type="button" data-goto="${n}" ${reachable ? "" : "disabled"} ${n === S.step ? 'aria-current="step"' : ""}>
        <small>${state === "done" ? icon("check") : "Step " + n}</small><span>${label}</span>
      </button></li>`;
  }).join("");
}

function fieldError(key) {
  return S.errors[key] ? `<p class="err" id="err-${key}">${icon("alert")}${esc(S.errors[key])}</p>` : "";
}

function bodyStep1() {
  const cur = chain().id;
  return `
    <h2 class="wiz-title">Choose a network</h2>
    <p class="lede">Your token will live on one network. You can launch the same token on another network later.</p>
    <div class="chain-grid" role="radiogroup" aria-label="Network">
      ${CHAINS.map((c) => `
        <label class="chain-card">
          <input type="radio" name="chain" value="${c.id}" ${c.id === cur ? "checked" : ""}>
          <span class="chain-card-in">${chainGlyph(c, "tok-lg")}<span class="cc-text"><b>${esc(c.name)}</b><small>${familyName(c)} · ${c.tag}</small></span></span>
        </label>`).join("")}
    </div>
    <div class="wiz-actions"><button class="btn btn-primary" type="button" data-next>Continue</button></div>`;
}

function brandingBlock() {
  if (S.brandingRemoved) {
    return `<p class="hint hint-ok">${icon("check")} Branding removed — your description won't include "${esc(BRAND_TAG)}".</p>`;
  }
  const fee = S.fees.brand;
  ensureFeeQuote(fee, BRANDING_FEE_USD);
  let amountText = "";
  if (fee.quote) amountText = ` (~${plain(fee.quote.amount)} ${fee.quote.symbol})`;
  else if (fee.quoteLoading) amountText = " (fetching price…)";
  return `
    <p class="hint">Every token's description includes "<b>${esc(BRAND_TAG)}</b>" by default. Preview: <code id="descPreview">${esc(finalDescription())}</code></p>
    <button class="btn btn-quiet btn-sm" type="button" data-remove-brand ${fee.paying || !fee.quote ? "disabled" : ""}>
      ${fee.paying ? "Sending…" : `Remove branding — $${BRANDING_FEE_USD}${amountText}`}
    </button>
    ${fee.quoteError ? `<p class="err">${icon("alert")}${esc(fee.quoteError)}</p>` : ""}
    ${fee.error ? `<p class="err">${icon("alert")}${esc(fee.error)}</p>` : ""}`;
}

function bodyStep2() {
  const d = decimals();
  return `
    <h2 class="wiz-title">Define your token</h2>
    <p class="lede">These details become public on ${esc(chain().name)} once you deploy.</p>
    <div class="fields">
      <div class="f ${S.errors.name ? "bad" : ""}">
        <label for="fName">Token name</label>
        <input id="fName" data-f="name" maxlength="32" placeholder="My Token" autocomplete="off" value="${esc(S.name)}" ${S.errors.name ? 'aria-invalid="true" aria-describedby="err-name"' : ""}>
        ${fieldError("name")}
      </div>
      <div class="f ${S.errors.symbol ? "bad" : ""}">
        <label for="fSymbol">Ticker</label>
        <input id="fSymbol" data-f="symbol" maxlength="10" placeholder="MYTKN" autocomplete="off" autocapitalize="characters" value="${esc(S.symbol)}" ${S.errors.symbol ? 'aria-invalid="true" aria-describedby="err-symbol"' : ""}>
        ${fieldError("symbol")}
      </div>
      <div class="f ${S.errors.supply ? "bad" : ""}">
        <label for="fSupply">Total supply</label>
        <input id="fSupply" data-f="supply" inputmode="numeric" placeholder="1000000000" autocomplete="off" value="${esc(S.supply)}" ${S.errors.supply ? 'aria-invalid="true" aria-describedby="err-supply"' : ""}>
        ${fieldError("supply")}
      </div>
      <div class="f ${S.errors.decimals ? "bad" : ""}">
        <label for="fDecimals">Decimals</label>
        <input id="fDecimals" data-f="decimals" inputmode="numeric" maxlength="2" autocomplete="off" value="${S.decimalsTouched ? esc(S.decimals) : d}" ${S.errors.decimals ? 'aria-invalid="true" aria-describedby="err-decimals"' : ""}>
        <p class="hint">${chain().family === "evm" ? "18 is standard on EVM networks." : `${chain().defaultDecimals} is common on ${esc(chain().name)}.`}</p>
        ${fieldError("decimals")}
      </div>
      <div class="f f-wide">
        <label for="fDesc">Description <span class="opt">optional</span></label>
        <textarea id="fDesc" data-f="desc" rows="3" maxlength="200" placeholder="What is this token for?">${esc(S.desc)}</textarea>
        <p class="hint" id="descCount">${S.desc.length}/200</p>
        ${brandingBlock()}
      </div>
    </div>
    <h3 class="wiz-subtitle">Social links <span class="opt">optional</span></h3>
    <p class="lede">Help people find and trust your project once it's live.</p>
    <div class="fields">
      <div class="f ${S.errors.website ? "bad" : ""}">
        <label for="fWebsite">Website</label>
        <input id="fWebsite" data-f="website" maxlength="100" placeholder="yourtoken.com" autocomplete="off" value="${esc(S.website)}" ${S.errors.website ? 'aria-invalid="true" aria-describedby="err-website"' : ""}>
        ${fieldError("website")}
      </div>
      <div class="f ${S.errors.twitter ? "bad" : ""}">
        <label for="fTwitter">X (Twitter)</label>
        <input id="fTwitter" data-f="twitter" maxlength="100" placeholder="@yourtoken or x.com/yourtoken" autocomplete="off" value="${esc(S.twitter)}" ${S.errors.twitter ? 'aria-invalid="true" aria-describedby="err-twitter"' : ""}>
        ${fieldError("twitter")}
      </div>
      <div class="f ${S.errors.telegram ? "bad" : ""}">
        <label for="fTelegram">Telegram</label>
        <input id="fTelegram" data-f="telegram" maxlength="100" placeholder="t.me/yourtoken" autocomplete="off" value="${esc(S.telegram)}" ${S.errors.telegram ? 'aria-invalid="true" aria-describedby="err-telegram"' : ""}>
        ${fieldError("telegram")}
      </div>
      <div class="f ${S.errors.discord ? "bad" : ""}">
        <label for="fDiscord">Discord</label>
        <input id="fDiscord" data-f="discord" maxlength="100" placeholder="discord.gg/yourtoken" autocomplete="off" value="${esc(S.discord)}" ${S.errors.discord ? 'aria-invalid="true" aria-describedby="err-discord"' : ""}>
        ${fieldError("discord")}
      </div>
    </div>
    <div class="wiz-actions"><button class="btn btn-quiet" type="button" data-back>Back</button><button class="btn btn-primary" type="button" data-next>Review</button></div>`;
}

function bodyStep3() {
  const c = chain();
  return `
    <h2 class="wiz-title">Review your token</h2>
    <p class="lede">Deployed tokens are permanent. Check every detail before you continue.</p>
    <div class="review">
      <section>
        <div class="review-head"><h3>Network</h3><button class="link" type="button" data-goto="1">Edit</button></div>
        <dl class="kv"><div><dt>Network</dt><dd>${esc(c.name)}</dd></div><div><dt>Type</dt><dd>${familyName(c)}</dd></div></dl>
      </section>
      <section>
        <div class="review-head"><h3>Token</h3><button class="link" type="button" data-goto="2">Edit</button></div>
        <dl class="kv">
          <div><dt>Name</dt><dd>${esc(S.name.trim())}</dd></div>
          <div><dt>Ticker</dt><dd>${esc(S.symbol)}</dd></div>
          <div><dt>Total supply</dt><dd>${groupSupply(S.supply)}</dd></div>
          <div><dt>Decimals</dt><dd>${decimals()}</dd></div>
          <div><dt>Description</dt><dd>${esc(finalDescription())}${S.brandingRemoved ? "" : ` <span class="opt">(includes NXT CLOUD branding)</span>`}</dd></div>
        </dl>
      </section>
      ${Object.keys(socials()).length ? `
      <section>
        <div class="review-head"><h3>Social links</h3><button class="link" type="button" data-goto="2">Edit</button></div>
        <dl class="kv">
          ${SOCIAL_FIELDS.filter((k) => S[k].trim()).map((k) => `<div><dt>${esc(SOCIAL_LABEL[k])}</dt><dd>${esc(S[k].trim())}</dd></div>`).join("")}
        </dl>
      </section>` : ""}
    </div>
    <label class="check ${S.errors.confirm ? "bad" : ""}">
      <input type="checkbox" id="fConfirm" ${S.confirmed ? "checked" : ""}>
      <span>I've checked these details and understand they can't be changed after deployment.</span>
    </label>
    ${S.errors.confirm ? `<p class="err">${icon("alert")}${esc(S.errors.confirm)}</p>` : ""}
    <div class="wiz-actions"><button class="btn btn-quiet" type="button" data-back>Back</button><button class="btn btn-primary" type="button" data-next>Continue</button></div>`;
}

function bodyStep4() {
  const checks = preflight();
  return `
    <h2 class="wiz-title">Deploy</h2>
    <p class="lede">Finish these checks, then deploy from your wallet.</p>
    <ul class="checks">
      ${checks.map((c, i) => `
        <li class="${c.ok ? "ok" : "todo"}">
          <span class="ck">${c.ok ? icon("check") : icon("alert")}</span>
          <span class="ck-text">${esc(c.text)}</span>
          ${c.fix ? `<button class="btn btn-quiet btn-sm" type="button" data-fix="${i}">${esc(c.fix.label)}</button>` : ""}
        </li>`).join("")}
    </ul>
    <div class="wiz-actions">
      <button class="btn btn-quiet" type="button" data-back>Back</button>
      <button class="btn btn-quiet" type="button" data-export>${icon("download")}Export config</button>
      <button class="btn btn-primary" type="button" data-deploy>Deploy token</button>
    </div>`;
}

function renderBody(focus = false) {
  const html = [bodyStep1, bodyStep2, bodyStep3, bodyStep4][S.step - 1]();
  $("#wizBody").innerHTML = html;
  renderStepper();
  renderTicket();
  if (focus) {
    const t = $(".wiz-title", $("#wizBody"));
    if (t) { t.setAttribute("tabindex", "-1"); t.focus({ preventScroll: true }); }
  }
}

function renderTicket() {
  const c = chain();
  const valid = S.name.trim() && S.symbol;
  $("#ticket").innerHTML = `
    <div class="ticket-top">
      <span class="tok tok-xl${S.symbol.length > 3 ? " long" : ""}" style="--h:${c.hue}" aria-hidden="true">${esc((S.symbol || "?").slice(0, 4))}</span>
      <div>
        <b class="ticket-name">${valid ? esc(S.name.trim()) : "Your token"}</b>
        <small>${S.symbol ? esc(S.symbol) + " on " : "on "}${esc(c.name)}</small>
      </div>
    </div>
    <div class="ticket-tear" aria-hidden="true"></div>
    <dl class="ticket-rows">
      <div><dt>Network</dt><dd>${esc(c.name)}</dd></div>
      <div><dt>Supply</dt><dd>${groupSupply(S.supply)}</dd></div>
      <div><dt>Decimals</dt><dd>${decimals()}</dd></div>
      <div><dt>Signed by</dt><dd>Your wallet</dd></div>
    </dl>
    <p class="ticket-note">${icon("check")}<span><b>Non-custodial.</b> NXT CLOUD never holds your keys or funds.</span></p>
    <button class="link ticket-reset" type="button" id="resetLaunch">Start over</button>`;
}

/* ---------------- navigation ---------------- */

function goto(n, focus = true) {
  S.step = n;
  S.reached = Math.max(S.reached, n);
  renderBody(focus);
}

function next() {
  if (S.step === 2) {
    S.errors = validate();
    if (Object.keys(S.errors).length) {
      renderBody(false);
      const first = $(".f.bad input, .f.bad textarea");
      if (first) first.focus();
      return;
    }
    S.errors = {};
    S.confirmed = false;
    return goto(3);
  }
  if (S.step === 3) {
    if (!S.confirmed) { S.errors = { confirm: "Confirm the details to continue." }; renderBody(false); return; }
    S.errors = {};
    return goto(4);
  }
  goto(S.step + 1);
}

function back() {
  S.errors = {};
  goto(Math.max(1, S.step - 1));
}

function download() {
  const cfg = config();
  const blob = new Blob([JSON.stringify(cfg, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${(cfg.token.symbol || "token").toLowerCase()}-${chain().id}-config.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  toast("Config downloaded");
}

function deploy() {
  const checks = preflight();
  const blocked = checks.find((c) => !c.ok);
  if (blocked) {
    toast(blocked.fix ? blocked.text : "Fix the highlighted check to continue.");
    const fix = $("[data-fix]", $("#wizBody"));
    if (fix) fix.focus();
    return;
  }
  const cfg = config();
  const launchFee = cfg.fees.launch;
  const brandFee = cfg.fees.branding;
  $("#deployBody").innerHTML = `
    <dl class="kv">
      <div><dt>Token</dt><dd>${esc(cfg.token.name)} (${esc(cfg.token.symbol)})</dd></div>
      <div><dt>Network</dt><dd>${esc(cfg.network)}</dd></div>
      <div><dt>Supply</dt><dd>${groupSupply(cfg.token.totalSupply)}</dd></div>
      <div><dt>Deployer</dt><dd>${esc(wallet.shortAddress())}</dd></div>
      <div><dt>Description</dt><dd>${esc(cfg.token.description)}</dd></div>
      <div><dt>Launch fee</dt><dd>$${launchFee.usd} paid${launchFee.native ? ` (${plain(launchFee.native.amount)} ${esc(launchFee.native.symbol)})` : ""} → ${esc(wallet.shortAddress(cfg.fees.treasury))}</dd></div>
      <div><dt>Branding</dt><dd>${brandFee.removed ? `Removed — $${brandFee.usd} paid${brandFee.native ? ` (${plain(brandFee.native.amount)} ${esc(brandFee.native.symbol)})` : ""}` : `Included by default (remove for $${BRANDING_FEE_USD} in Step 2)`}</dd></div>
    </dl>
    <div class="callout">${icon("alert")}<p><b>Token deployment itself isn't connected yet.</b> Your $${LAUNCH_FEE_USD} launch fee was sent to the treasury wallet, but this build has no token program or contract to create the token, so nothing further was signed or spent. Export the config to keep your setup.</p></div>
    <div class="sheet-actions">
      <button class="btn btn-quiet" type="button" id="depCopy">${icon("copy")}Copy config</button>
      <button class="btn btn-primary" type="button" id="depDownload">${icon("download")}Download config</button>
    </div>`;
  $("#depCopy").addEventListener("click", async () => toast((await copyText(JSON.stringify(config(), null, 2))) ? "Config copied" : "Couldn't copy the config"));
  $("#depDownload").addEventListener("click", download);
  openDialog($("#deployDialog"));
}

function resetAll() {
  Object.assign(S, {
    step: 1, reached: 1, name: "", symbol: "", supply: "", decimals: "", decimalsTouched: false, desc: "",
    website: "", twitter: "", telegram: "", discord: "", confirmed: false, errors: {},
    brandingRemoved: false, fees: { launch: freshFee(), brand: freshFee() },
  });
  try { localStorage.removeItem("nxt.draft"); } catch { /* ignore */ }
  renderBody(true);
  toast("Started over");
}

/* ---------------- init ---------------- */

export function init() {
  loadDraft();
  const root = $("#launchpad");

  root.addEventListener("click", (e) => {
    const t = e.target;
    const go = t.closest("[data-goto]");
    if (go && !go.disabled) return goto(Number(go.dataset.goto));
    if (t.closest("[data-next]")) return next();
    if (t.closest("[data-back]")) return back();
    if (t.closest("[data-export]")) return download();
    if (t.closest("[data-deploy]")) return deploy();
    if (t.closest("#resetLaunch")) return resetAll();
    if (t.closest("[data-remove-brand]")) return payFee(S.fees.brand, BRANDING_FEE_USD, () => { S.brandingRemoved = true; });
    const fix = t.closest("[data-fix]");
    if (fix) { const item = preflight()[Number(fix.dataset.fix)]; if (item && item.fix) item.fix.run(); }
  });

  root.addEventListener("change", (e) => {
    if (e.target.name === "chain") {
      store.set({ chain: e.target.value });
      const checked = $('input[name="chain"]:checked', root);
      if (checked) checked.focus();   // the step re-renders; keep keyboard focus on the group
    }
    if (e.target.id === "fConfirm") { S.confirmed = e.target.checked; if (S.confirmed) { S.errors = {}; renderBody(false); $("#fConfirm").focus(); } }
  });

  root.addEventListener("input", (e) => {
    const key = e.target.dataset.f;
    if (!key) return;
    let v = e.target.value;
    if (key === "symbol") v = v.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
    if (key === "supply") v = v.replace(/\D/g, "").replace(/^0+(?=\d)/, "").slice(0, 24);
    if (key === "decimals") { v = v.replace(/\D/g, "").slice(0, 2); S.decimalsTouched = v !== ""; }
    if (v !== e.target.value) e.target.value = v;
    S[key] = v;
    if (S.errors[key]) {                      // clear an error once the value is fixed
      const now = validate();
      if (!now[key]) { delete S.errors[key]; const box = e.target.closest(".f"); box.classList.remove("bad"); const er = $(".err", box); if (er) er.remove(); e.target.removeAttribute("aria-invalid"); }
    }
    if (key === "desc") {
      $("#descCount").textContent = `${v.length}/200`;
      const preview = $("#descPreview");
      if (preview) preview.textContent = finalDescription();
    }
    saveDraft();
    renderTicket();
  });

  let lastChain = store.get().chain;
  store.subscribe(() => {
    S.errors = {};
    const curChain = store.get().chain;
    if (curChain !== lastChain) {
      // A paid fee (or a fix in progress) doesn't carry over to a different network —
      // each network is its own deploy, so the launch fee and branding removal are per-chain.
      lastChain = curChain;
      Object.assign(S.fees.launch, { tx: null, error: null, paying: false });
      Object.assign(S.fees.brand, { tx: null, error: null, paying: false });
      S.brandingRemoved = false;
    }
    if (S.active) renderBody(false); else renderTicket();
  });
  wallet.subscribe(() => { if (S.active && S.step === 4) renderBody(false); });

  document.addEventListener("route", (e) => {
    S.active = e.detail === "launchpad";
    if (S.active) renderBody(false);
  });

  renderBody(false);
}
