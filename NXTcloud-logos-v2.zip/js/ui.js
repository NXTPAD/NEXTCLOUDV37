// Small DOM + formatting helpers shared by every module.
import { getCoinImages } from "./api.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

export const icon = (name, cls = "") => `<svg class="i ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;

/**
 * Every coin/chain bubble always renders instantly as the plain letter-bubble
 * first (so it's never blank, never a broken image, and needs no network) —
 * then, if it carries a `data-cg` (CoinGecko id), initTokUpgrade()'s
 * MutationObserver picks it up and swaps in the real logo once it loads.
 */
function tokBubble(cgId, fallbackText, hue, size, extraClass = "") {
  const cls = `tok ${size}${extraClass}`.trim();
  const cgAttr = cgId ? ` data-cg="${esc(cgId)}"` : "";
  return `<span class="${cls}" style="--h:${hue}"${cgAttr} aria-hidden="true">${esc(fallbackText)}</span>`;
}

/** A coin's real logo (with a letter-bubble fallback) for use anywhere a token is shown. */
export function tokenAvatar(token, size = "") {
  const long = token.symbol.length > 3 ? " long" : "";
  return tokBubble(token.cg, token.symbol.slice(0, 4), token.hue, size, long);
}

/** A network's real logo (with a letter-bubble fallback) for use anywhere a chain is shown. */
export function chainGlyph(chain, size = "") {
  return tokBubble(chain.cg, chain.name[0], chain.hue, size);
}

/**
 * Wires up the background upgrade: watches the whole page for `.tok[data-cg]`
 * bubbles (present now or added later by any module's re-renders) and swaps
 * each to its real logo via getCoinImages(), batching ids across bubbles that
 * appear together. A bubble that has no CoinGecko id, whose fetch fails, or
 * whose image itself fails to load simply stays the letter-bubble — nothing
 * here can produce a blank or broken-looking bubble. Call once at startup.
 */
export function initTokUpgrade() {
  const pending = new Set();
  let timer = null;

  const flush = async () => {
    timer = null;
    const nodes = [...pending].filter((n) => n.isConnected && !n.dataset.resolved);
    pending.clear();
    if (!nodes.length) return;
    const ids = [...new Set(nodes.map((n) => n.dataset.cg))];
    let images;
    try {
      images = await getCoinImages(ids);
    } catch {
      return; // leave every bubble as its letter-fallback; nothing to clean up
    }
    for (const n of nodes) {
      if (n.dataset.resolved || !n.isConnected) continue;
      n.dataset.resolved = "1";
      const url = images[n.dataset.cg];
      if (!url) continue;
      const img = document.createElement("img");
      img.className = n.className;
      const style = n.getAttribute("style");
      if (style) img.setAttribute("style", style);
      img.alt = "";
      img.loading = "lazy";
      img.setAttribute("aria-hidden", "true");
      img.onerror = () => img.isConnected && img.replaceWith(n.cloneNode(true)); // real URL still 404s: revert to the bubble
      img.src = url;
      n.replaceWith(img);
    }
  };

  const queue = (el) => {
    pending.add(el);
    if (!timer) timer = setTimeout(flush, 80);
  };
  const scan = (root) => { if (root.querySelectorAll) $$(".tok[data-cg]:not([data-resolved])", root).forEach(queue); };

  scan(document);
  new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType !== 1) continue;
        if (node.matches && node.matches(".tok[data-cg]:not([data-resolved])")) queue(node);
        scan(node);
      }
    }
  }).observe(document.body, { childList: true, subtree: true });
}

let toastTimer;
export function toast(message) {
  const el = $("#toast");
  if (!el) return;
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 3200);
}

/** USD price with sensible precision for both $60,000 assets and $0.00002 assets. */
export function fmtUsd(n) {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1000) return "$" + n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  if (n >= 1) return "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  if (n <= 0) return "$0.00";
  const decimals = Math.min(12, Math.max(2, 2 - Math.floor(Math.log10(n))));
  return "$" + n.toFixed(decimals);
}

/** Plain machine-friendly number string (no grouping, no exponent, trailing zeros trimmed). */
export function plain(n) {
  if (n == null || !isFinite(n)) return "";
  let s;
  if (n >= 1000) s = n.toFixed(2);
  else if (n >= 1) s = n.toFixed(4);
  else if (n <= 0) s = "0";
  else s = n.toFixed(Math.min(12, Math.max(6, 3 - Math.floor(Math.log10(n)))));
  return s.replace(/(\.\d*?[1-9])0+$/, "$1").replace(/\.0+$/, "");
}

/** Grouped amount for display. */
export function fmtAmount(n) {
  if (n == null || !isFinite(n)) return "—";
  if (n >= 1000) return n.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return Number(plain(n)).toLocaleString("en-US", { maximumFractionDigits: 12 });
}

export function fmtChange(n) {
  if (n == null || !isFinite(n)) return { text: "—", dir: "flat" };
  const dir = n > 0.005 ? "up" : n < -0.005 ? "down" : "flat";
  const glyph = dir === "up" ? "▲" : dir === "down" ? "▼" : "•";
  return { text: `${glyph} ${Math.abs(n).toFixed(2)}%`, dir };
}

export function debounce(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.cssText = "position:fixed;opacity:0";
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch { /* ignore */ }
    ta.remove();
    return ok;
  }
}

export function openDialog(dlg) {
  if (!dlg.open) dlg.showModal();
}

/** Wire backdrop-click and [data-close] buttons on every dialog once. */
export function initDialogs() {
  $$("dialog.sheet").forEach((dlg) => {
    // Delegated so buttons rendered into a dialog later (previews, deploy summary) also close it.
    dlg.addEventListener("click", (e) => {
      if (e.target === dlg || e.target.closest("[data-close]")) dlg.close();
    });
  });
}

export function friendlyError(e) {
  const msg = (e && (e.message || e.reason)) || "";
  if (e && (e.code === 4001 || e.code === "ACTION_REJECTED" || /reject|denied|declin|cancel/i.test(msg))) return "You cancelled the request in your wallet.";
  if (e && e.code === -32002) return "A request is already open in your wallet. Check the extension.";
  return msg || "The wallet request failed. Try again.";
}
