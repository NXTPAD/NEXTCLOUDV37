// Networks and tokens known to the interface.

export const FAMILY_LABEL = { solana: "Solana", evm: "EVM", sui: "Sui" };

// Real logos, served from Trust Wallet's public asset CDN (well-established,
// no API key). `logo: null` values below fall back to the old letter-bubble —
// see tokenAvatar()/chainGlyph() in ui.js, which also fall back automatically
// if any of these URLs ever stop resolving.
const TW = "https://cdn.jsdelivr.net/gh/trustwallet/assets@master/blockchains";
const LOGO = {
  solana: `${TW}/solana/info/logo.png`,
  ethereum: `${TW}/ethereum/info/logo.png`,
  base: `${TW}/base/info/logo.png`,
  bnb: `${TW}/smartchain/info/logo.png`,
  polygon: `${TW}/polygon/info/logo.png`,
  arbitrum: `${TW}/arbitrum/info/logo.png`,
  avalanche: `${TW}/avalanchec/info/logo.png`,
  sui: `${TW}/sui/info/logo.png`,
  jup: `${TW}/solana/assets/JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN/logo.png`,
  bonk: `${TW}/solana/assets/DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263/logo.png`,
  // These three aren't on Trust Wallet's list under a bare ticker path, so they come from a second, equally common icon set.
  wbtc: "https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/wbtc.png",
  usdc: "https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/usdc.png",
  usdt: "https://cdn.jsdelivr.net/gh/spothq/cryptocurrency-icons@master/128/color/usdt.png",
};

export const CHAINS = [
  { id: "solana", name: "Solana", family: "solana", native: "SOL", tag: "Popular", hue: 265, defaultDecimals: 9, reserve: 0.01, logo: LOGO.solana },
  { id: "ethereum", name: "Ethereum", family: "evm", chainId: "0x1", native: "ETH", tag: "Popular", hue: 225, defaultDecimals: 18, reserve: 0.005, logo: LOGO.ethereum },
  {
    id: "base", name: "Base", family: "evm", chainId: "0x2105", native: "ETH", tag: "Popular", hue: 220, defaultDecimals: 18, reserve: 0.0005, logo: LOGO.base,
    add: { chainName: "Base", rpcUrls: ["https://mainnet.base.org"], blockExplorerUrls: ["https://basescan.org"], nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 } },
  },
  {
    id: "bnb", name: "BNB Chain", family: "evm", chainId: "0x38", native: "BNB", tag: "Supported", hue: 42, defaultDecimals: 18, reserve: 0.002, logo: LOGO.bnb,
    add: { chainName: "BNB Smart Chain", rpcUrls: ["https://bsc-dataseed.binance.org"], blockExplorerUrls: ["https://bscscan.com"], nativeCurrency: { name: "BNB", symbol: "BNB", decimals: 18 } },
  },
  {
    id: "polygon", name: "Polygon", family: "evm", chainId: "0x89", native: "POL", tag: "Supported", hue: 275, defaultDecimals: 18, reserve: 0.5, logo: LOGO.polygon,
    add: { chainName: "Polygon", rpcUrls: ["https://polygon-rpc.com"], blockExplorerUrls: ["https://polygonscan.com"], nativeCurrency: { name: "POL", symbol: "POL", decimals: 18 } },
  },
  {
    id: "arbitrum", name: "Arbitrum", family: "evm", chainId: "0xa4b1", native: "ETH", tag: "Supported", hue: 205, defaultDecimals: 18, reserve: 0.0005, logo: LOGO.arbitrum,
    add: { chainName: "Arbitrum One", rpcUrls: ["https://arb1.arbitrum.io/rpc"], blockExplorerUrls: ["https://arbiscan.io"], nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 } },
  },
  {
    id: "avalanche", name: "Avalanche", family: "evm", chainId: "0xa86a", native: "AVAX", tag: "Supported", hue: 355, defaultDecimals: 18, reserve: 0.02, logo: LOGO.avalanche,
    add: { chainName: "Avalanche C-Chain", rpcUrls: ["https://api.avax.network/ext/bc/C/rpc"], blockExplorerUrls: ["https://snowtrace.io"], nativeCurrency: { name: "Avalanche", symbol: "AVAX", decimals: 18 } },
  },
  { id: "sui", name: "Sui", family: "sui", native: "SUI", tag: "Supported", hue: 195, defaultDecimals: 9, reserve: 0.05, logo: LOGO.sui },
];

// cg = CoinGecko asset id, home = the network used when opening this token from the home page.
export const TOKENS = {
  SOL: { symbol: "SOL", name: "Solana", cg: "solana", hue: 265, home: "solana", logo: LOGO.solana },
  ETH: { symbol: "ETH", name: "Ether", cg: "ethereum", hue: 225, home: "ethereum", logo: LOGO.ethereum },
  BNB: { symbol: "BNB", name: "BNB", cg: "binancecoin", hue: 42, home: "bnb", logo: LOGO.bnb },
  POL: { symbol: "POL", name: "Polygon", cg: "polygon-ecosystem-token", hue: 275, home: "polygon", logo: LOGO.polygon },
  AVAX: { symbol: "AVAX", name: "Avalanche", cg: "avalanche-2", hue: 355, home: "avalanche", logo: LOGO.avalanche },
  SUI: { symbol: "SUI", name: "Sui", cg: "sui", hue: 195, home: "sui", logo: LOGO.sui },
  ARB: { symbol: "ARB", name: "Arbitrum", cg: "arbitrum", hue: 205, home: "arbitrum", logo: LOGO.arbitrum },
  JUP: { symbol: "JUP", name: "Jupiter", cg: "jupiter-exchange-solana", hue: 150, home: "solana", logo: LOGO.jup },
  BONK: { symbol: "BONK", name: "Bonk", cg: "bonk", hue: 24, home: "solana", logo: LOGO.bonk },
  WBTC: { symbol: "WBTC", name: "Wrapped Bitcoin", cg: "wrapped-bitcoin", hue: 28, home: "ethereum", logo: LOGO.wbtc },
  USDC: { symbol: "USDC", name: "USD Coin", cg: "usd-coin", hue: 212, stable: true, home: "ethereum", logo: LOGO.usdc },
  USDT: { symbol: "USDT", name: "Tether", cg: "tether", hue: 165, stable: true, home: "ethereum", logo: LOGO.usdt },
};

export const CHAIN_TOKENS = {
  solana: ["SOL", "USDC", "USDT", "JUP", "BONK"],
  ethereum: ["ETH", "USDC", "USDT", "WBTC"],
  base: ["ETH", "USDC"],
  bnb: ["BNB", "USDT", "USDC"],
  polygon: ["POL", "USDC", "USDT"],
  arbitrum: ["ETH", "ARB", "USDC", "USDT"],
  avalanche: ["AVAX", "USDC", "USDT"],
  sui: ["SUI", "USDC"],
};

export const TAPE = ["SOL", "ETH", "BNB", "POL", "AVAX", "SUI", "ARB", "JUP", "WBTC", "BONK"];

// TODO: swap in your real treasury wallets before going live. These are
// widely-recognized placeholder addresses (an EVM burn address and the
// Solana System Program id) so they pass normal address-format checks
// without being mistaken for a real destination.
export const TREASURY = {
  evm: "0x000000000000000000000000000000000000dEaD",
  solana: "11111111111111111111111111111111",
};

export const chainById = (id) => CHAINS.find((c) => c.id === id) || CHAINS[0];
export const chainTokens = (chainId) => (CHAIN_TOKENS[chainId] || []).map((s) => TOKENS[s]);
export const chainByEvmId = (hex) => CHAINS.find((c) => c.chainId && c.chainId === String(hex).toLowerCase());
