// Networks and tokens known to the interface.

export const FAMILY_LABEL = { solana: "Solana", evm: "EVM", sui: "Sui" };

// `cg` = CoinGecko asset id, used only for price/chart lookups (via the
// server-side /api/prices and /api/chart proxy).
//
// `logo` = a direct, static image URL for the coin's real logo. This is
// intentionally a plain <img src> (see tokBubble() in ui.js) rather than
// something resolved at runtime from an API response: CoinGecko's REST API
// has no CORS headers, so the browser can't call it directly with fetch(),
// and this deployment's own /api/* proxy isn't reachable either — but an
// <img> tag's request isn't subject to CORS at all, so a direct URL is the
// only approach that actually renders regardless of either of those. Icons
// come from CoinCap's public icon CDN (assets.coincap.io/assets/icons),
// keyed by lowercase ticker. If a URL ever 404s, the bubble's onerror simply
// removes the <img> and the plain-letter fallback underneath shows through —
// it can never render as a blank circle. Base has no native coin on CoinCap
// (it's an L2, not its own priced asset), so its `logo` points instead at
// Base's own network brand mark from Trust Wallet's asset repo.
export const CHAINS = [
  { id: "solana", name: "Solana", family: "solana", native: "SOL", tag: "Popular", hue: 265, defaultDecimals: 9, reserve: 0.01, cg: "solana", logo: "https://assets.coincap.io/assets/icons/sol@2x.png" },
  { id: "ethereum", name: "Ethereum", family: "evm", chainId: "0x1", native: "ETH", tag: "Popular", hue: 225, defaultDecimals: 18, reserve: 0.005, cg: "ethereum", logo: "https://assets.coincap.io/assets/icons/eth@2x.png" },
  {
    id: "base", name: "Base", family: "evm", chainId: "0x2105", native: "ETH", tag: "Popular", hue: 220, defaultDecimals: 18, reserve: 0.0005, cg: null, logo: "https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/base/info/logo.png",
    add: { chainName: "Base", rpcUrls: ["https://mainnet.base.org"], blockExplorerUrls: ["https://basescan.org"], nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 } },
  },
  {
    id: "bnb", name: "BNB Chain", family: "evm", chainId: "0x38", native: "BNB", tag: "Supported", hue: 42, defaultDecimals: 18, reserve: 0.002, cg: "binancecoin", logo: "https://assets.coincap.io/assets/icons/bnb@2x.png",
    add: { chainName: "BNB Smart Chain", rpcUrls: ["https://bsc-dataseed.binance.org"], blockExplorerUrls: ["https://bscscan.com"], nativeCurrency: { name: "BNB", symbol: "BNB", decimals: 18 } },
  },
  {
    id: "polygon", name: "Polygon", family: "evm", chainId: "0x89", native: "POL", tag: "Supported", hue: 275, defaultDecimals: 18, reserve: 0.5, cg: "polygon-ecosystem-token", logo: "https://assets.coincap.io/assets/icons/matic@2x.png",
    add: { chainName: "Polygon", rpcUrls: ["https://polygon-rpc.com"], blockExplorerUrls: ["https://polygonscan.com"], nativeCurrency: { name: "POL", symbol: "POL", decimals: 18 } },
  },
  {
    id: "arbitrum", name: "Arbitrum", family: "evm", chainId: "0xa4b1", native: "ETH", tag: "Supported", hue: 205, defaultDecimals: 18, reserve: 0.0005, cg: "arbitrum", logo: "https://assets.coincap.io/assets/icons/arb@2x.png",
    add: { chainName: "Arbitrum One", rpcUrls: ["https://arb1.arbitrum.io/rpc"], blockExplorerUrls: ["https://arbiscan.io"], nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 } },
  },
  {
    id: "avalanche", name: "Avalanche", family: "evm", chainId: "0xa86a", native: "AVAX", tag: "Supported", hue: 355, defaultDecimals: 18, reserve: 0.02, cg: "avalanche-2", logo: "https://assets.coincap.io/assets/icons/avax@2x.png",
    add: { chainName: "Avalanche C-Chain", rpcUrls: ["https://api.avax.network/ext/bc/C/rpc"], blockExplorerUrls: ["https://snowtrace.io"], nativeCurrency: { name: "Avalanche", symbol: "AVAX", decimals: 18 } },
  },
  { id: "sui", name: "Sui", family: "sui", native: "SUI", tag: "Supported", hue: 195, defaultDecimals: 9, reserve: 0.05, cg: "sui", logo: "https://assets.coincap.io/assets/icons/sui@2x.png" },
];

// cg = CoinGecko asset id (price/chart only), logo = direct icon URL (see note above),
// home = the network used when opening this token from the home page.
export const TOKENS = {
  SOL: { symbol: "SOL", name: "Solana", cg: "solana", logo: "https://assets.coincap.io/assets/icons/sol@2x.png", hue: 265, home: "solana" },
  ETH: { symbol: "ETH", name: "Ether", cg: "ethereum", logo: "https://assets.coincap.io/assets/icons/eth@2x.png", hue: 225, home: "ethereum" },
  BNB: { symbol: "BNB", name: "BNB", cg: "binancecoin", logo: "https://assets.coincap.io/assets/icons/bnb@2x.png", hue: 42, home: "bnb" },
  POL: { symbol: "POL", name: "Polygon", cg: "polygon-ecosystem-token", logo: "https://assets.coincap.io/assets/icons/matic@2x.png", hue: 275, home: "polygon" },
  AVAX: { symbol: "AVAX", name: "Avalanche", cg: "avalanche-2", logo: "https://assets.coincap.io/assets/icons/avax@2x.png", hue: 355, home: "avalanche" },
  SUI: { symbol: "SUI", name: "Sui", cg: "sui", logo: "https://assets.coincap.io/assets/icons/sui@2x.png", hue: 195, home: "sui" },
  ARB: { symbol: "ARB", name: "Arbitrum", cg: "arbitrum", logo: "https://assets.coincap.io/assets/icons/arb@2x.png", hue: 205, home: "arbitrum" },
  JUP: { symbol: "JUP", name: "Jupiter", cg: "jupiter-exchange-solana", logo: "https://assets.coincap.io/assets/icons/jup@2x.png", hue: 150, home: "solana" },
  BONK: { symbol: "BONK", name: "Bonk", cg: "bonk", logo: "https://assets.coincap.io/assets/icons/bonk@2x.png", hue: 24, home: "solana" },
  WBTC: { symbol: "WBTC", name: "Wrapped Bitcoin", cg: "wrapped-bitcoin", logo: "https://assets.coincap.io/assets/icons/wbtc@2x.png", hue: 28, home: "ethereum" },
  USDC: { symbol: "USDC", name: "USD Coin", cg: "usd-coin", logo: "https://assets.coincap.io/assets/icons/usdc@2x.png", hue: 212, stable: true, home: "ethereum" },
  USDT: { symbol: "USDT", name: "Tether", cg: "tether", logo: "https://assets.coincap.io/assets/icons/usdt@2x.png", hue: 165, stable: true, home: "ethereum" },
};

export const CHAIN_TOKENS = {
  solana: ["SOL", "USDC", "USDT", "JUP", "BONK"],
  ethereum: ["ETH", "USDC", "USDT", "WBTC"],
  base: ["ETH", "USDC"],
  bnb: ["BNB", "USDT", "USDC"],
  polygon: ["POL", "USDC", "USDT"],
  arbitrum: ["ETH", "ARB", "USDC", "USDT"],
  avalanche: ["AVAX", "USDC", "USDT"],
  sui: ["SUI", "USDC"],
};

export const TAPE = ["SOL", "ETH", "BNB", "POL", "AVAX", "SUI", "ARB", "JUP", "WBTC", "BONK"];

// TODO: swap in your real treasury wallets before going live. These are
// widely-recognized placeholder addresses (an EVM burn address and the
// Solana System Program id) so they pass normal address-format checks
// without being mistaken for a real destination.
export const TREASURY = {
  evm: "0x000000000000000000000000000000000000dEaD",
  solana: "11111111111111111111111111111111",
};

export const chainById = (id) => CHAINS.find((c) => c.id === id) || CHAINS[0];
export const chainTokens = (chainId) => (CHAIN_TOKENS[chainId] || []).map((s) => TOKENS[s]);
export const chainByEvmId = (hex) => CHAINS.find((c) => c.chainId && c.chainId === String(hex).toLowerCase());
